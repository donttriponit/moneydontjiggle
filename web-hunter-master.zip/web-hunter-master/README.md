# web-hunter
Crawl Google and Bing to find emails, subdomains and URLs associated to a target domain

Need some spare time to rewrite this tool as I would like to add support for more websites such as pastebin, shodan, eripp, dnshistory, pgp key servers etc. you get the idea. I also would like to allow the user to search for specific regular expressions, while -u, -e and -s would become pre-defined regexes.

## TODOs

* add https://dnsdumpster.com/
