<?php

// ruleid: assert-use
assert($user_input);

// ok: assert-use
assert('2 > 1');

// todook: assert-use
assert($user_input > 1);
