<?php

echo `ping -n 3 {$user_input}`;

?>