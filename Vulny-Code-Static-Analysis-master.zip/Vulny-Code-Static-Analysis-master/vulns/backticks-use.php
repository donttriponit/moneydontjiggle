<?php

// ruleid: backticks-use
echo `ping -n 3 {$user_input}`;
