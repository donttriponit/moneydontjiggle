<?php

// ruleid: phpinfo-use
echo phpinfo();
