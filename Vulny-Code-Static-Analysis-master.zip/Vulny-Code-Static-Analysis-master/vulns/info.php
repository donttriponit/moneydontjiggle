<?php
    // Comment
    phpinfo();
?>