<?php
  define("USERNAME", "admin");
  define("PASSWORD", "pwd123*");

  $DB_HOST = "localhost";
	$DB_NAME = "securitychalls";
	$DB_USER = "admin";
	$DB_PASS = "password";
	$DB_CHALL_ONE = "graduatecms";
	$DB_CHALL_TWO = "androidcompare";
  $secret_flag ="a2'&vkzg%";
  $token = "1213144142353962062";
  $pwd   = "mysuper_cr3dz";
  $pass  = $pwd.$token;
  $Pass  = "case!nsenSitiveP@ss";
  $base64 = "TXlTdXBlclBhc3N3b3JkCg==";
  $base64 = "TXlTdXBlclBhc3N3b3JkT3IganVzdCBhbm90aGVyIGJhY2tkb29yIGluIHlvdXIgY29kZSB5b3Ugd2FudCB0byBiZSBkZXRlY3RlZAo=";
  $hex = "4d79537570657250617373776f72644f72206a75737420616e6f74686572206261636b646f6f7220696e20796f757220636f646520796f752077616e7420746f2062652064657465637465640a";
  $fakeAPI1 = "AIzad8e8fca2dc0f896fd7cb4cb0031ba249123";
  $fakeAPI2 = "AKIAD8E8FCA2DC0F896F";
  $hash2 = "$1$VnG/6ABB$t6w9bQFxvI9tf0sFJf2TR.";
  $hash3 = "d8e8fca2dc0f896fd7cb4cb0031ba249";

  if($pass == "$6$q8C1F6tv$zTP/eEVixqyQBEfsSbTidUJfnaE2ojNIpTwTHava/UhFORv3V4ehyTOGdQEoFo1dEVG6UcXwhG.UHvyQyERz01"){
    echo "Hardcoded !";
  }
?>