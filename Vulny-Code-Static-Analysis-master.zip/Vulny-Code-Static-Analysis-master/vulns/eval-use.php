<?php

// ruleid: eval-use
eval($user_input);

// ok: eval-use
eval('echo "OK"');
