<html>
		<?php
			if (isset($_POST['mail'])){
				$mail = md5($_POST['mail']);
			}
		?>
</html>
