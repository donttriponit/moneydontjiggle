// Package script aims to make it easy to write shell-type scripts in Go, for
// general system administration purposes: reading files, counting lines,
// matching strings, and so on.
package script
