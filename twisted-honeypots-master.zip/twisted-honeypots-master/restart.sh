#!/bin/bash

$(dirname $0)/stop.sh
$(dirname $0)/start.sh
