export MYSQL_USER=pot_user
export MYSQL_DB=pot_db
export MYSQL_PWD=password
export TWISTED_PID=/var/run/twistd-pot.pid
export TWISTED_LOG=/var/log/twistd-pot.log
export PYTHONPATH=${PYTHONPATH}:/opt/twisted-honeypots/python
